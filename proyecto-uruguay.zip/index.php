<?php
$op = 0;
include "./Publico/Paginas/enunciado.php";
include "./Publico/Html/Head.php";
include "./Publico/Html/Header.php";
include "./Publico/Html/Inicio.php";
include "./Publico/Html/Footer.php";

//inicio de la aplicación 
