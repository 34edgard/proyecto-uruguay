<?php
$op =2;
include "./validar_sesion.php";
include "./enunciado.php";
include "../Html/Head.php";
include "../Html/Header.php";
include "../Html/Inscripciones_paso_2.php";
include "../Html/Footer.php";