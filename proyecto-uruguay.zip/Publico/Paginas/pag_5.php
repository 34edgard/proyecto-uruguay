<?php
$op =5;
include "./validar_sesion.php";
include "./enunciado.php";
include "../Html/Head.php";
include "../Html/Header.php";
include "../Html/Aulas.php";
include "../Html/Footer.php";