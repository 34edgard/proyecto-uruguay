<?php
$op = 9;

include "./enunciado.php";

include "../Html/Head.php";
include "../Html/Header.php";
include "../Html/Inicio_sesion.php";
include "../Html/Footer.php";


