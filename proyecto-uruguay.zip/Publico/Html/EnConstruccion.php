    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <img src="/Publico/Img/en-construccion.png" alt="Esta parte esta en construcción" class="img-fluid mb-4" style="max-width: 400px;">  <!-- Reemplaza con tu imagen -->
                <h1>Esta parte del Sistema esta en Construcción</h1>
                <p class="lead">Estamos trabajando duro para mejorar esta parte sistema web.  Vuelve pronto para ver las novedades.</p>
                <p>Gracias por tu paciencia.</p>
                <!-- Puedes agregar un formulario de contacto si lo deseas -->
                <!-- <form>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="email" aria-describedby="emailHelp">
                    </div>
                    <button type="submit" class="btn btn-primary">Suscribirse a actualizaciones</button>
                </form> -->
            </div>
        </div>
    </div>
    