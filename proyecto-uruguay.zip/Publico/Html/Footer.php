</main>
<?php if($op ==0): ?>
<!--<footer class="footer mt-auto container-flex px-2 py-5">
<div class="row p-1">
<div class="col-md-2 themed-grid-col">
<h5>Bachilleres</h5>
<ul class="nav flex-column">
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">Edgard Patete</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">Luis Castellar</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">Luisana Rodrigez</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">Diego Días</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">Ashley Rivas</a></li>
</ul>
</div>

<div class="col-md-2 themed-grid-col">
<h5>Cedula</h5>
<ul class="nav flex-column">
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">30117454</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">30013991</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">29879208</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">30198726</a></li>
<li class="nav-item mb-2"><a href="./#" class="nav-link p-0 text-muted">30576759</a></li>
</ul>
</div>
<div class="col-md-2 themed-grid-col"></div>


<div class="col-md-4 themed-grid-col offset-1">

<h5>Profesora de proyecto</h5>
<p>
Alvis Zacarias
</p>
<div class="d-flex w-100 gap-2">



</div>

</div>
</div>

<div class="d-flex justify-content-between py-4 my-4 border-top">
<p>
© P.F.G: Informatica para la Gestion Social.
</p>

</div>
</footer>-->
<?php endif; ?>


<script src='/Publico/Estilos/js/bootstrap.bundle.min.js'></script>


</body>

</html>