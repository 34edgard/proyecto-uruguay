<div class="container mt-5">
  <div class="container d-flex ">
    <a class="btn btn-primary" href="/Publico/Paginas/pag_0.php">
      Iniciar Sesión 
    </a>
  </div>
  
  <h1 class="text-center">Bienvenida al sistema</h1>
<div class="offcanvas-body p-3 row">
	  <div class="col-md-10 themed-grid-col my-3">
    <div class="card">
      <img src="/Publico/Img/img-1.jpeg" class="card-img-top" alt="niños el uruguay" style="height:250px;  ">
      <div class="card-body">
        <h5 class="card-title">Su inicio</h5>
        <p class="card-text">Mucha gente cree que la escuela República del Uruguay fue construida por Peréz Jiménez, pero no es así. Fue creado por la presidencia del general Isaías Medina Angarita y fue la primera edificación construida en el estado Monagas por el gobierno nacional con fines escolares.</p>
      </div>
    </div>
  </div>
  <div class="col-md-10 themed-grid-col my-3">
    <div class="card">
      <img src="/Publico/Img/img-2.jpg" class="card-img-top" alt="imagen1 lll" style="height:250px;  " >
      <div class="card-body">
        <h5 class="card-title">Su fundacion</h5>
        <p class="card-text"> Escuela Republica Del Uruguay, se construye  en el año 1.944 bajo el gobierno del General Isaías Medina Angarita, quien previamentehabía establecido mediante Decreto Presidencial que todas las escuela creadas apartir el año 1.942 debían llevar el nombre de países latinoamericanos.</p>
      </div>
    </div>
  </div>
  <div class="col-md-10 themed-grid-col my-3">
    <div class="card">
      <img src="/Publico/Img/img-3.jpg" class="card-img-top" alt="escuela-republica" style="height:250px;  " >
      <div class="card-body">
        <h5 class="card-title">Inaguaración</h5>
        <p class="card-text">el 16 de octubre de 1.946 cuando abre sus puertas como Grupo Escolar yfue oficialmente inaugurado el 1ero de noviembre de 1947 bajo la Dirección delProfesor Alberto Garantón Barrozzi, quien venía de prestar servicios en la escuela dela Creole Petroleum Corporatión.</p>
      </div>
    </div>
  </div>
  <div class="col-md-10 themed-grid-col my-3">
    <div class="card">
      <img src="/Publico/Img/img-4.jpeg" class="card-img-top" alt="escuela uruguay"  style="height:250px;  ">
      <div class="card-body">
        <h5 class="card-title">Actualidad</h5>
        <p class="card-text">El gobierno de Medina Angarita creó este proyecto de colocarle nombre de países a todas las escuelas que construyó en Venezuela. Malaussena también diseñó el viejo aeropuerto de Maturín ,detrás del parque La Guaricha</p>
      </div>
    </div>
  </div>
</div>
</div>