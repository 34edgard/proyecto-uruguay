
<!--	<button class="btn color-1">color 1</button>
	<button class="btn color-2">color 2</button>
	<button class="btn color-3">color 3</button>
	<button class="btn color-4">color 4</button>
	<button class="btn color-5">color 5</button>-->
<div class="container text-center mt-5 bg-white rounded thumbnail">

<a href="/Publico/Paginas/pag_2_p1.php"
class="btn btn-primary m-5">inscribir un nuevo ingreso</a>

<a href="/Publico/Paginas/pag_2_p.php"
class="btn btn-primary m-5">promovidos</a>

</div>

