
<form action="Pag_3.3.php">
	<fieldset class="container  thumbnail">
<h1 class="text-center text-primary m-2">paso 2 inscripcion</h1>
<label class="label-control">
  nivel 
  <select name="nivel" class="form-control">
    <option value="1">primer nivel</option>
    <option value="2">segundo nivel</option>
    <option value="3">terser nivel</option>
  </select>
</label>
		<button type="submit" class="btn btn-primary">envíar</button><button type="reset" class="btn btn-danger">borrar</button>





	</fieldset>
</form>