<div class="container">
  <h1 class="text-center text-primary">
    Aulas
  </h1>
  <form>
    <label class="label-control">
      periodo
      <select name="periodo" class="form-control">
        <option value="2">2019-2020</option>
        <option value="1">2018-2019</option>
      </select>
    </label>
    <label class="label-control">
      edad
      <input type="number" name="edad" class="form-control">
    </label>
    <label class="label-control">
      sexo
      <select name="sexo" class="form-control">
        <option value="1">masculino</option>
        <option value="2">femenino</option>
      </select>
    </label>
    <button type="button" name="generarReporteAula" class="btn btn-success">
      Generar Reporte
    </button>
  </form>
  <div class="container">
    <div class='card mb-3' style='max-width: 18rem;'>
  <div class='card-header'>aula numero </div>
  <div class='card-body'>
    <h5 class='card-title'>seccion a</h5>
    <table class='table table-bordered border-5 text-dark'>
  <tr>
    <td colspan='2'></td>
    <td>v</td>
    <td>h</td>
  </tr>
  <tr>
    <td>3 años</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td>4 años</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
    <tr>
    <td>5 años</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
    <tr>
    <td>6 años</td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  
</table>
  </div>
</div>
  </div>
</div>