<!DOCTYPE html>
  <html lang="es">
    <head>
      <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Sistema de gestión escolar del preescolar República del Uruguay">
    <meta name="author" content="Edgard Patete">
    <meta name="generator" content="Hugo 0.88.1">
        <link rel="shortcut icon" href="/Publico/Img/Logo.jpg" type="image/x-icon" />
      <title>
        <?= Enunciado($op); ?>
  </title>
       <script defer src="/Codigo_js/Librerias/htmx.js"></script>
      <link rel="stylesheet" href="/Publico/Estilos/css/bootstrap.min.css">
      <link rel="stylesheet" href="/Publico/Estilos/css/estilos.css">
    </head>
    <body>