<form action="Pag_3.3.php">
	<fieldset class="container  thumbnail">
<h1 class="text-center text-primary m-2">Promovidos</h1>
<label class="label-control">
  nivel 
  <select name="nivel" class="form-control">
    <option value="1">primer nivel</option>
    <option value="2">segundo nivel</option>
    <option value="3">terser nivel</option>
  </select>
</label>
		<button type="submit" class="btn btn-primary">Promover</button>



<div class="table-responsive">
  <table class="table bordered">
    <tr>
      <td>cedula</td>
      <td>nombre apellido</td>
      <td>fecha de nacimiento</td>
      <td>edad</td>
      <td>sexo</td>
    </tr>
  </table>
</div>

	</fieldset>
</form>