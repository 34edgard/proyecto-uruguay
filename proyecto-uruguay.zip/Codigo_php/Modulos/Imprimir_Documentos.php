<?php

include './includer.php';

Peticion::metodo_get();