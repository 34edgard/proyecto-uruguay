<?php

const puerto = "sql210.infinityfree.com";
const usuario_BD = "if0_37533972";
const contraceña_BD = "PoRkldd3vL";
const nombre_BD = "if0_37533972_Proyecto_v6";
