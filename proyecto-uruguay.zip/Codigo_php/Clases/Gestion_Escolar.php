<?php
class inscripcion{
}
class año_escolar{
  
}
class fecha_inscripcion{
  
}
class periodo_escolar{
  
}