<?php
(function (){
  global $registrarNiños;
  $registrarNiños = function (){
    echo "hola   d";
  };
  })();